using CaloriesTest.Packeges;

namespace CaloriesTest
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
            // instantiation of objects that will be used in the unit test
            List<Recipe> recipe = new List<Recipe>();
            List<Ingredient> ingredients = new List<Ingredient>();
            // setting the number of calories of an ingredient to 300 to trigger the method when it is needed
            ingredients.Add(new Ingredient { Calory = 300 });
            recipe.Add(new Recipe { Ingredients = ingredients });
            string expected = $"**********************************************************\n" +
                        $"Calory Warning! Recipe has MORE THAN 300 CALORIES\n" +
                        $"************************************************************";
            string actual = recipe[0].calWarn(recipe[0].Ingredients[0].Calory);

            Assert.AreEqual(expected, actual);
        }
    }
}