﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace design
{
    public class Step
    {
        // step properties declaration
        private string instruction;

        public String Instruction
        {
            get { return instruction; }
            set { instruction = value; }
        }
    }
}
