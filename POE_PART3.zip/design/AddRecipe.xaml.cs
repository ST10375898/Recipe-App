﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace design
{
    /// <summary>
    /// Interaction logic for AddRecipe.xaml
    /// </summary>
    public partial class AddRecipe : Page
    {
        public List<Recipe> recipes = new List<Recipe>();
        public List<Ingredient> ingredients = new List<Ingredient>();
        public List<Step> steps = new List<Step>();
        public AddRecipe()
        {
            InitializeComponent();
        }

        private void SaveIngredient_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                ingredients.Add(new Ingredient
                {
                    Name = ingredientName.Text,
                    Quantity = double.Parse(quantity.Text),
                    Unit = unit.Text,
                    Group = foodGroup.Text,
                    Calory = double.Parse(calories.Text),
                });
                MessageBox.Show($"Ingredient {ingredients.Count} successfully added!");
            }catch(FormatException ex)
            {
                MessageBox.Show($"Input INVALID. Please enter a Number!");
                return;
            }
           
            
        }

        private void AddIngredient_Click(object sender, RoutedEventArgs e)
        {
            ingredientName.Text = string.Empty;
            quantity.Text = string.Empty;
            unit.Text = string.Empty;
            foodGroup.Text = string.Empty;
            calories.Text = string.Empty;
            ingredientName.Focus();
            int recipeCount = ingredients.Count;
            ingredientCounter.Content = $"~Ingredient {recipeCount+1} Details~";
        }

        private void SaveStep_Click(object sender, RoutedEventArgs e)
        {
            steps.Add(new Step { Instruction = stepInstruction.Text, });
            MessageBox.Show($"Step {steps.Count} Successfully Added");
        }

        private void AddStep_Click(object sender, RoutedEventArgs e)
        {
            stepInstruction.Text = string.Empty;
            stepInstruction.Focus();

            int stepCount = steps.Count;
            stepCounter.Content = $"~Step {stepCount+1} Description~"; 
        }

        private void saveRecipe_Click(object sender, RoutedEventArgs e)
        {
            recipes.Add(new Recipe {
                Ingredients = ingredients, 
                Name = recipeName.Text, 
                Steps = steps });

           
            try
            {
                MessageBox.Show($"{recipes[recipes.Count - 1].Name} Recipe Successfully Added.");
            }catch(IndexOutOfRangeException) 
            {
                MessageBox.Show("No recipes on system yet");
            }

            ingredientName.Text = string.Empty;
            quantity.Text = string.Empty;
            unit.Text = string.Empty;
            foodGroup.Text = string.Empty;
            calories.Text = string.Empty;
            stepInstruction.Text = string.Empty;
            recipeName.Text = string.Empty;
            recipeName.Focus();


            MainWindow mainWindow = Application.Current.Windows.OfType<MainWindow>().FirstOrDefault();
            mainWindow.recipes.AddRange(recipes);
        }
    }
}
