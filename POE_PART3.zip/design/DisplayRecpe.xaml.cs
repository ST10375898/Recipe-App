﻿using System;
using System.Collections.Generic;
using System.Collections.Immutable;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace design
{
    /// <summary>
    /// Interaction logic for DisplayRecipe.xaml
    /// </summary>
    public partial class DisplayRecpe : Page
    {
        public List<Recipe> recipes = new List<Recipe>();
        public DisplayRecpe()
        {
            InitializeComponent();
        }

        private void searchBtn_Click(object sender, RoutedEventArgs e)
        {
            recipeList.Items.Clear();
            bool itemFound = false;
            if (searchIngrdient.IsChecked == true)
            {
                foreach (var recipe in recipes)
                {
                    foreach (var ingredient in recipe.Ingredients)
                    {
                        if (ingredient.Name.Trim().ToUpper() == searchTerm.Text.Trim().ToUpper())
                        {
                            itemFound = true;
                            recipeList.Items.Add(recipe.Name);
                            MessageBox.Show($"Recipe List Filtered Successfully");
                        }
                        else
                        {
                            itemFound = false;
                        }
                    }
                }
                if (itemFound == false)
                {
                    MessageBox.Show($"No Recipe contains '{searchTerm.Text}' ingredient.");
                    foreach (var recip in recipes)
                    {
                        recipeList.Items.Add(recip.Name);
                    }
                }
            }
            else if(searchGroup.IsChecked == true)
            {
                foreach (var recipe in recipes)
                {
                    foreach (var ingredient in recipe.Ingredients)
                    {
                        if (ingredient.Group.Trim().ToUpper() == searchTerm.Text.Trim().ToUpper())
                        {
                            itemFound = true;
                            recipeList.Items.Add(recipe.Name);
                            MessageBox.Show($"Recipe List Filtered Successfully");
                        }
                        else
                        {
                            itemFound = false;
                        }
                    }
                }
                if (itemFound == false)
                {
                    MessageBox.Show($"No Recipe contains '{searchTerm.Text}' food group.");
                    foreach (var recip in recipes)
                    {
                        recipeList.Items.Add(recip.Name);
                    }
                }
            }
            else if(searchCalory.IsChecked == true)
            {
                try
                {
                    foreach (var recipe in recipes)
                    {
                        foreach (var ingredient in recipe.Ingredients)
                        {
                            if (ingredient.Calory == double.Parse(searchTerm.Text.Trim()))
                            {
                                itemFound = true;
                                recipeList.Items.Add(recipe.Name);
                                MessageBox.Show($"Recipe List Filtered Successfully");
                            }
                            else
                            {
                                itemFound = false;
                            }
                        }
                    }
                    if (itemFound == false)
                    {
                        MessageBox.Show($"No Recipe contains '{searchTerm.Text}' Number of Calories.");
                        foreach (var recip in recipes)
                        {
                            recipeList.Items.Add(recip.Name);
                        }
                    }
                }catch(FormatException ex)
                {
                    MessageBox.Show($"Invalid Search Term Please enter a number");
                    return;
                }
               
            }
           
            

        }

        private void outputRecipeDisplay_Click(object sender, RoutedEventArgs e)
        {
            foreach(var recipe in recipes)
            {
                if (recipe.Name.Equals(recipeList.SelectedItem))
                {
                    if(origionalScale.IsChecked == true)
                    {
                        display.Items.Clear();
                        display.Items.Add( recipe.DisplayRecipe(1));
                        display.Items.Add(recipe.displaySteps());

                    }
                    else if(doubleScale.IsChecked == true)
                    {
                        display.Items.Clear();
                        display.Items.Add(recipe.DisplayRecipe(2));
                        
                        display.Items.Add(recipe.displaySteps());
                    }
                    else if(tripleScale.IsChecked == true)
                    {
                        display.Items.Clear();
                        display.Items.Add(recipe.DisplayRecipe(3));
                        display.Items.Add(recipe.displaySteps());
                    }
                    else if(halfScale.IsChecked == true)
                    {
                        display.Items.Clear();
                        display.Items.Add(recipe.DisplayRecipe(0.5));
                        display.Items.Add(recipe.displaySteps());
                    }
                }
            }
        }

        private void chooseRecipe_Click(object sender, RoutedEventArgs e)
        {
            recipeList.Items.Clear();
            foreach(var recipe in recipes)
            {
                recipeList.Items.Add(recipe.Name);
            }
        }

        private void searchIngrdient_Click(object sender, RoutedEventArgs e)
        {
            filter.Header = "Ingredient";
        }

        private void searchGroup_Click(object sender, RoutedEventArgs e)
        {
            filter.Header = "Food Group";
        }

        private void searchCalory_Click(object sender, RoutedEventArgs e)
        {
            filter.Header = "Calories";
        }
    }
}
