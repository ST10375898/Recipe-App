﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace design
{
    public delegate string CalWarning(double calory);
    public class Recipe
    {
        private string name;
        private List<Ingredient> ingredients;
        private List<Step> steps;

        public string Name
        {
            get { return name; }
            set { name = value; }
        }

        public List<Step> Steps
        {
            get { return steps; }
            set { steps = value; }
        }

        public List<Ingredient> Ingredients
        {
            get { return ingredients; }
            set { ingredients = value; }
        }

        public string DisplayRecipe(double scale)
        {
            double caloryCount = 0;
            string finalOutput = "";
            string output = "";
            string name = Name;
            string[] recipeDetails = new string[ingredients.Count];
            for (int i = 0; i < Ingredients.Count; i++)
            {
                output = $"{i + 1}. {ingredients[i].Quantity * scale} {ingredients[i].Unit} of {ingredients[i].Name} " +
                    $"(Food Group: {ingredients[i].Group} | Calories: {ingredients[i].Calory * scale})";
                recipeDetails[i] = output;
                caloryCount += ingredients[i].Calory;
            }

            string ingredientOutput = String.Join('\n', recipeDetails);

            CalWarning warning = calWarn;

            string[] stepArray = new string[Steps.Count];
            string stepper = "";
            for (int i = 0; i < Steps.Count; i++)
            {
                stepper = $"{i + 1}. {steps[i].Instruction}";
                stepArray[i] = stepper;
            }

            string stepsOutput = String.Join("\n", stepArray);

            finalOutput = $"            Recipe Name : {name}\n" +
                          $"********************************************************" +
                          $"\n                  Ingredients:\n{ingredientOutput}\n" +
                          $"********************************************************" +
                          $"\nTotal Calories: {caloryCount * scale}\n" +
                          $"{warning.Invoke(caloryCount * scale)}\n";
            return finalOutput;
        }

        public string calWarn(double calory)
        {
            string output = "";
            if (calory >= 300)
            {
                output = $"**********************************************************\n" +
                        $"Calory Warning! Recipe has MORE THAN 300 CALORIES\n" +
                        $"************************************************************";
            }
            return output;
        }

        public string displaySteps()
        {
            string[] stepArray = new string[Steps.Count];
            string stepper = "";
            for (int i = 0; i < Steps.Count; i++)
            {
                stepper = $"{i + 1}. {steps[i].Instruction}";
                stepArray[i] = stepper;
            }

            string stepsOutput = String.Join("\n", stepArray);

            string lastOutput = $"********************************************************" +
                          $"\n                  Steps: \n{stepsOutput}\n" +
                          $"************* End of Recipe ****************************";
            return lastOutput;
        }
    }
}
